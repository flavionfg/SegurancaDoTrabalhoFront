var app = angular.module('myApp', ['ngMask']);
//função do Botão SAIR!!
function redirectTo(ref) {
	window.location.href = ref;
}

app.controller('myController',['$http','$scope' , function( $http,$scope){

	//botão SAIR
	$scope.onExit = function(){
		redirectTo("index.html");
	}



	$("#date").keypress(function (e) {
		return false;
	});

	$("input[name='dataFim']").keypress(function (e) {
		return false;
	});

	$scope.empresas;
	$scope.nrs = [];
	$scope.treinamento = {};
	$scope.funcionarios = [];
	$scope.todate;
	$scope.dataMinima;
	$scope.tipos;
	$scope.cpfUser = '';



	function dataHoje() {
		var data = new Date();
		var dia = data.getDate();
		dia = dia < 10  ? "0"+dia : dia;
		var mes = data.getMonth() + 1;
		mes = mes < 10  ? '0'+mes : mes;
		var ano = data.getFullYear();            
		return [ano, mes,dia ].join('-');
	}



	$scope.minDate = function(data){

		if(data <$scope.todate){
			$scope.plano.dataInicio = $scope.todate;
		}

		var dia = data.getDate();
		dia = dia < 10  ? "0"+dia : dia;
		var mes = data.getMonth() + 1;
		mes = mes < 10  ? '0'+mes : mes;
		var ano = data.getFullYear();            
		$scope.dataMinima = [ano, mes,dia ].join('-');    	
	}

	$scope.init = function () {

		$scope.cpfUser = localStorage.getItem('cpfUser');

		if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");


		$scope.todate = dataHoje();
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/empresauser/'+$scope.cpfUser}).then(function(response){
			$scope.empresas = response.data;

			if($scope.funcionarios === null || $scope.funcionarios === undefined){
				getShowToast('Erro','Um funcionario deve ser selecionado','error');
			}
		});
	};

	function getNrs(){

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/nrs'}).then(function(response){
			$scope.nrs = response.data;

		});

	}

	$scope.deslogar = function(){
		localStorage.clear();
		window.location="login.html";
	}


	$scope.saveTreinamento = function(treinamentofield){
		
		var listaFuncionario = [];
		var treinamento = treinamentofield;
		for(var i = 0, funcionarioAux; i < $scope.funcionarios.length;i++){
			funcionarioAux = $scope.funcionarios[i];
			if(funcionarioAux.ativo === true)
				listaFuncionario.push(funcionarioAux);
		}

		treinamento.funcionarios = listaFuncionario;

		var body = JSON.stringify(treinamento);

		$scope.treinamento = [];
		delete $scope.treinamento;
		$scope.treinamentoForm.$invalid = true;

		$http.post('http://localhost:8082/workSecurity/treinamento', body).then(function(response){	
			$scope.treinamentoForm.$setUntouched(true);
			if(response.status === 200 || response.status === 201 ){
				
				getShowToast('Sucesso','Salvo com sucesso, favor consultar a aba HISTORICO!','success');
			}else{

				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');

			}

		
		});

			
	}

	$scope.getFuncionarios = function(empresa){
		$scope.empresaSelecionada = empresa;
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/funcionarioempresa/'+empresa.id}).then(function(response){

			if($scope.funcionarios === null || $scope.funcionarios === undefined ||  $scope.funcionarios.length > 0)
				$scope.funcionarios = [];

			if(response.status === 200){

				for(var i = 0, funcionarioAux; i< response.data.length;i++){
					funcionarioAux = response.data[i];
					var funcionario = {};
					funcionario.id = funcionarioAux.id;
					funcionario.nome = funcionarioAux.nome;
					funcionario.setor = funcionarioAux.setor;
					funcionario.funcao = funcionarioAux.funcao;
					funcionario.cargo = funcionarioAux.cargo;
					funcionario.cpf =  funcionarioAux.cpf;
					funcionario.ativo = false;

					$scope.funcionarios.push(funcionario);

				}
				getJqueryDatatable();
				if($scope.funcionarios === null || $scope.funcionarios === undefined){
					$.toast({
						heading: 'Error',
						text: 'Os funcionarios não foram encontrados, favor cadastrar ',
						icon: 'error',
						position: 'top-center'
					});
				}
			}
		});
	}

	$scope.getTiponr = function(nr){

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/tiponr/'+nr}).then(function(response){
				var tipos = [];
				$scope.tipos = [];
				if(response.data.length > 0){

					for(var i = 0,tiposAux; i<= response.data.length;i++){
						tiposAux = response.data[i];
						$scope.tipos.push(angular.copy(tiposAux.tipo));
					}

				}else{
					tipos.push( response.data);
					for(var i = 0,tiposAux; i< tipos.length;i++){
						tiposAux = tipos[i];
						$scope.tipos.push(angular.copy(tiposAux.tipo));
					}

				}

				
				
		
		});
	}

	$scope.numeroNr = [
	{id:1 , numero:1},
	{id:2 , numero:2},
	{id:3 , numero:3},
	{id:4 , numero:4},
	{id:5 , numero:5},
	{id:6 , numero:6},
	{id:7 , numero:7},
	{id:8 , numero:8},
	{id:9 , numero:9},
	{id:10 , numero:10},
	{id:11 , numero:11},
	{id:12 , numero:12},
	{id:13 , numero:13},
	{id:14 , numero:14},
	{id:15 , numero:15},
	{id:16 , numero:16},
	{id:17 , numero:17},
	{id:18 , numero:18},
	{id:19 , numero:19},
	{id:20 , numero:20},
	{id:21 , numero:21},
	{id:22 , numero:22},
	{id:23 , numero:23},
	{id:24 , numero:24},
	{id:25 , numero:25},
	{id:26 , numero:26},
	{id:27 , numero:27},
	{id:28 , numero:28},
	{id:29 , numero:29},
	{id:30 , numero:30},
	{id:31 , numero:31},
	{id:32 , numero:32},
	{id:33 , numero:33},
	{id:34 , numero:34},
	{id:35 , numero:35},
	{id:36 , numero:36}
	];

	function getJqueryDatatable(){

		$('#table').DataTable().clear().destroy();
		$(document).ready(function() {
			
			$('#table').DataTable( {
				"language":{
					"sEmptyTable": "Nenhum registro encontrado",
					"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
					"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
					"sInfoFiltered": "(Filtrados de _MAX_ registros)",
					"sInfoPostFix": "",
					"sInfoThousands": ".",
					"sLengthMenu": "_MENU_ resultados por página",
					"sLoadingRecords": "Carregando...",
					"sProcessing": "Processando...",
					"sZeroRecords": "Nenhum registro encontrado",
					"sSearch": "Pesquisar",
					"oPaginate": {
						"sNext": "Próximo",
						"sPrevious": "Anterior",
						"sFirst": "Primeiro",
						"sLast": "Último"
					},
					"oAria": {
						"sSortAscending": ": Ordenar colunas de forma ascendente",
						"sSortDescending": ": Ordenar colunas de forma descendente"
					},
					"showButtonPanel":  false
				},
				"order": [[ 5, "desc" ]]
			} );          
		} );     
	}

	
	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			position: 'top-center'
		});
	}

}]);

