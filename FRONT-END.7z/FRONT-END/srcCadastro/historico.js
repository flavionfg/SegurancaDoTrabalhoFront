var app = angular.module('myApp', ['ngMask']);

function redirectTo(ref) {
	window.location.href = ref;
}



app.controller('myController',['$scope', '$http', function($scope, $http,$window){
	$scope.treinamentos = [];
	$scope.cpfUser = '';
	$scope.empresa = '';
	$scope.init = function () {


		$scope.cpfUser = localStorage.getItem('cpfUser');

		if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/empresauser/'+$scope.cpfUser}).then(function(response){
			
			if(response.status === 200 || response.status === 201 ){
				if(response.data === null || response.data === undefined ){
					getShowToast('Erro','As empresas não foram encontradas','error');
					return;
				}
				$scope.empresas = response.data;


			}
			else{
				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
			}
		});
	}; 

	$scope.getTreinamentos = function(empresa){
		$scope.empresa = empresa;
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/treinamentofuncionario/'+empresa.id}).then(function(response){
			
			
			if(response.status === 200 || response.status === 201 ){
				if(response.data === null || response.data === undefined ){
					getShowToast('Erro','As empresas não foram encontradas','error');
					return;
				}
				$scope.allTreinamentos = response.data;

			}
			else{
				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
			}
		});
	}


	$scope.deslogar = function(){
		localStorage.clear();
		window.location="login.html";
	}

	
	$scope.getListaTreinamentos = function(dataInicial,dataFinal){
		
		//delete $scope.treinamentos;
		$scope.treinamentos = [];

		getJqueryDatatable();

		for(var i = 0, treinamento; i < $scope.allTreinamentos.length ;i++){
			treinamento = angular.copy($scope.allTreinamentos[i]);

			

			var inicial = (new Date(treinamento.dataInicial)).toLocaleString('pt-BR');
			var final = (new Date(treinamento.dataFinal)).toLocaleString('pt-BR');


			if( (new Date(dataInicial)).toLocaleString('pt-BR') <= inicial && 
				(new Date(dataFinal)).toLocaleString('pt-BR') >= final){

				treinamento.dataInicial = inicial.substring(10,0);
				treinamento.dataFinal =  final.substring(10,0);

				$scope.treinamentos.push(angular.copy(treinamento));
			}

		}
		
	}

	$scope.getPlanoTrabalhos = function(empresa){

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/planostrabalho/'+empresa.id}).then(function(response){
			
			
			if(response.status === 200 || response.status === 201 ){
				if(response.data === null || response.data === undefined ){
					getShowToast('Erro','As empresas não foram encontradas','error');
					return;
				}
				$scope.allPlanoTrabalhos = response.data;
				

			}
			else{
				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
			}
		});
	}

	$scope.getListaPlanoTrabalho = function(dataInicial,dataFinal){
		
		
		$scope.planoTrabalhos = [];

		getJqueryDatatable2();

		for(var i = 0, plano; i < $scope.allPlanoTrabalhos.length ;i++){
			plano = angular.copy($scope.allPlanoTrabalhos[i]);

			var inicial = (new Date(plano.dataInicial)).toLocaleString('pt-BR');
			var final = (new Date(plano.dataFinal)).toLocaleString('pt-BR');


			if( (new Date(dataInicial)).toLocaleString('pt-BR') <= inicial && 
				(new Date(dataFinal)).toLocaleString('pt-BR') >= final){

				plano.dataInicial = inicial.substring(10,0);
				plano.dataFinal =  final.substring(10,0);
	 
				$scope.planoTrabalhos.push(angular.copy(plano));
			}

		}
		
	}


	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			position: 'top-center'
		});
	}

	function getJqueryDatatable2(){
		$('#table2').DataTable().clear().destroy();
		$(document).ready(function() {
			
			$('#table2').DataTable( {
				"language":{
					"sEmptyTable": "Nenhum registro encontrado",
					"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
					"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
					"sInfoFiltered": "(Filtrados de _MAX_ registros)",
					"sInfoPostFix": "",
					"sInfoThousands": ".",
					"sLengthMenu": "_MENU_ resultados por página",
					"sLoadingRecords": "Carregando...",
					"sProcessing": "Processando...",
					"sZeroRecords": "Nenhum registro encontrado",
					"sSearch": "Pesquisar",
					"oPaginate": {
						"sNext": "Próximo",
						"sPrevious": "Anterior",
						"sFirst": "Primeiro",
						"sLast": "Último"
					},
					"oAria": {
						"sSortAscending": ": Ordenar colunas de forma ascendente",
						"sSortDescending": ": Ordenar colunas de forma descendente"
					},
					"showButtonPanel":  false
				},
				"order": [[ 5, "desc" ]]
			} );          
		} );     
	}

	function getJqueryDatatable(){
		$('#table').DataTable().clear().destroy();
		$(document).ready(function() {
			
			$('#table').DataTable( {
				"language":{
					"sEmptyTable": "Nenhum registro encontrado",
					"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
					"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
					"sInfoFiltered": "(Filtrados de _MAX_ registros)",
					"sInfoPostFix": "",
					"sInfoThousands": ".",
					"sLengthMenu": "_MENU_ resultados por página",
					"sLoadingRecords": "Carregando...",
					"sProcessing": "Processando...",
					"sZeroRecords": "Nenhum registro encontrado",
					"sSearch": "Pesquisar",
					"oPaginate": {
						"sNext": "Próximo",
						"sPrevious": "Anterior",
						"sFirst": "Primeiro",
						"sLast": "Último"
					},
					"oAria": {
						"sSortAscending": ": Ordenar colunas de forma ascendente",
						"sSortDescending": ": Ordenar colunas de forma descendente"
					},
					"showButtonPanel":  false
				},
				"order": [[ 5, "desc" ]]
			} );          
		} );     
	}


}]);