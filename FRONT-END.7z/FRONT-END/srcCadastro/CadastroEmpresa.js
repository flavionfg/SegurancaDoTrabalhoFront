var app = angular.module('myApp', ['angular.viacep','ngMask','ngFileUpload',"ngSanitize", "ngCsv"]);

function redirectTo(ref) {
	window.location.href = ref;
}

app.controller('myController',['$scope', '$http', function($scope, $http,$window){

	$scope.setores = [];
	var mapSetor = new Map();

	$scope.onExit = function(){
		redirectTo("index.html");
	}
 	$scope.cpfUser = '';

	function startFildEmpresa(){
		$scope.empresa = {
			cep: null,
			logradouro: null,
			bairro: null,
			uf: null,
			cidade: null,
		}
	};

	$scope.init = function () {


		$scope.cpfUser = localStorage.getItem('cpfUser');

		if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");

		startFildEmpresa();
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/empresauser/'+$scope.cpfUser}).then(function(response){
			
			if(response.status === 200 || response.status === 201 ){
				if(response.data === null || response.data === undefined ){
					getShowToast('Erro','As empresas não foram encontradas','error');
					return;
				}
				getJqueryDatatable();
				$scope.empresas = angular.copy(response.data);
			}
			else{
				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
			}
		});
	}; 

	$scope.deslogar = function(){
		localStorage.clear();
		window.location="login.html";
	}

	//função salva a empresa e setor e faz a listagem de empresa no datatable
	$scope.saveEmpresa = function(empresa){
		$scope.empresa = empresa;
		$scope.empresa.cpfUser = $scope.cpfUser;
		$scope.body = angular.toJson($scope.empresa);
		$http.post('http://localhost:8082/workSecurity/empresa', $scope.body).then(function(response){	

			if(response.status === 200 || response.status === 201 ){			
				salvaSetor();
				$scope.init();			
				getShowToast('Sucesso','Salvo com sucesso','success');	
				$scope.setores = [];
				delete $scope.empresaForm;		
			}
		},function(error){ if(error.status === 500){
			getShowToast('Erro','CNPJ já cadastrado no sistema, favor conferir os dados!','error');
		}else{
			getShowToast('Erro','Erro ao realizar a operação, favor conferir os campos!','error');
		}
		});


	}



	//função pega valor do fileupload
	$scope.SelectFile = function (file) {
		$scope.SelectedFile = file;
	};

	// função converte o arquivo csv
	$scope.Upload = function () {
		var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv|.txt)$/;
		if (regex.test($scope.SelectedFile.name.toLowerCase())) {
			if (typeof (FileReader) != "undefined") {
				var reader = new FileReader();
				reader.onload = function (e) {
					var customers = new Array();
					$scope.rows = e.target.result.split("\r\n");
					var setores = converterJson($scope.rows);

					for(var i = 0; i < setores.length; i++){
						var setor = {};

						var empresa = {}
						empresa.id = $scope.empresa.id;

						setor.nome = setores[i].nome;
						setor.id = 0;
						
						if($scope.empresa.id !== null && $scope.empresa.id !== undefined)
							setor.idEmpresa = empresa;

						if(setor.nome != null && setor.nome != undefined && setor.nome.trim() != "" ){

							if(!mapSetor.has(setor.nome)){
								$scope.setores.push(setor);
								mapSetor.set(setor.nome,setor.nome);
							}
						}
					}
				}
				reader.readAsText($scope.SelectedFile);
			} else {
				$window.alert("This browser does not support HTML5.");
			}
		} else {
			$window.alert("Please upload a valid CSV file.");
		}
	}

	//função auxiliar para conversão do csv
	function converterJson($scope){

		if($scope === null || isFinite($scope)) return;
		
		var headers= $scope[0].split(";");
		var result = [];
		for(var i=1;i<$scope.length;i++){

			var obj = {};
			var currentline=$scope[i].split(";");

			for(var j=0;j<headers.length;j++){
				obj[headers[j]] = currentline[j];
			}

			result.push(obj);

		}
		return result;
	}

	// função que transforma objeto empresa em json
	$scope.setorJson = function(){

		$scope.setorBody = angular.toJson($scope.setores);

	};

	// função inclui setores na lista
	$scope.adicionaSetor = function(nome){
		var setor = {};
		var empresa = {}
		empresa.id = $scope.empresa.id;
		setor.nome = nome;		
		setor.idEmpresa = empresa;
		if(!mapSetor.has(setor.nome)){
			
			$scope.setores.push(setor);
			mapSetor.set(setor.nome,setor.nome);
		}else{
			getShowToast('Erro','Este setor já existe, favor inserir outro setor!','error');
		}

		// Limpar campo setor para inserir novo registro.
		 $scope.setor = [];

	}
	// função para salvar setor
	function salvaSetor(){

		$scope.body = [];
		
		$scope.body = angular.toJson($scope.setores);

		$http.post('http://localhost:8082/workSecurity/setor', $scope.body).then(function(response){	
		
		
		});
		
	}

	//função carrega ver Empresa
	$scope.getEmpresa = function(empresa){
		$scope.verEmpresa = empresa;
	}

	

	// função carrega informação da empresa para atualização de cadastro
	$scope.editarEmpresa = function(empresa){

		$scope.setores = [];
		startFildEmpresa();
		mapSetor = new Map();
		$scope.empresa = angular.copy(empresa);

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/allsetor/'+empresa.id}).then(function(response){
			if(response.status === 200 || response.status === 201 ){
				var setores = response.data;
				for(var i = 0; i < setores.length; i++){

						if(!mapSetor.has(setores[i].nome)){
							$scope.setores.push(setores[i]);
							mapSetor.set(setores[i].nome,setores[i].nome);
						}
					
				}
			} 
		});
		


	}

	function getJqueryDatatable(){
		$('#table').DataTable().clear().destroy();
		$(document).ready(function() {
			
			$('#table').DataTable( {
				"language":{
					"sEmptyTable": "Nenhum registro encontrado",
					"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
					"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
					"sInfoFiltered": "(Filtrados de _MAX_ registros)",
					"sInfoPostFix": "",
					"sInfoThousands": ".",
					"sLengthMenu": "_MENU_ resultados por página",
					"sLoadingRecords": "Carregando...",
					"sProcessing": "Processando...",
					"sZeroRecords": "Nenhum registro encontrado",
					"sSearch": "Pesquisar",
					"oPaginate": {
						"sNext": "Próximo",
						"sPrevious": "Anterior",
						"sFirst": "Primeiro",
						"sLast": "Último"
					},
					"oAria": {
						"sSortAscending": ": Ordenar colunas de forma ascendente",
						"sSortDescending": ": Ordenar colunas de forma descendente"
					},
					"showButtonPanel":  false
				},
				"order": [[ 5, "desc" ]]
			} );          
		} );     
	}

	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			position: 'top-center'
		});
	}


}]);

