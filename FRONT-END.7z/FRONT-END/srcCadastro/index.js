var app = angular.module('myApp', []);

app.controller('myController',['$http','$scope' , function( $http,$scope){
	$scope.treinamentos = {};
	$scope.cpfUser = '';

	$scope.init = function () {

	/*	
	Adiciona valor ao localStoreage
	localStorage.setItem('nome', 'leandro');	

	Pega valor do local storage
	var nome = localStorage.getItem('nome');

	limpa os dados da local storage
	localStorage.clear();
	*/

		$scope.cpfUser = localStorage.getItem('cpfUser');

		if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");
		
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/treinamentos/'+$scope.cpfUser}).then(function(response){
			
			$scope.treinamentos = JSON.stringify(response.data);

			am4core.ready(function() {

				// Themes begin
				am4core.useTheme(am4themes_animated);
				// Themes end

				// Create chart instance
				var chart = am4core.create("chartdiv", am4charts.XYChart3D);

				// Add data
				chart.data = response.data;

				// Create axes
				let categoryAxis = chart.xAxes.push(new am4charts.CategoryAxis());
				categoryAxis.dataFields.category = "empresa";
				categoryAxis.renderer.labels.template.rotation = 270;
				categoryAxis.renderer.labels.template.hideOversized = false;
				categoryAxis.renderer.minGridDistance = 20;
				categoryAxis.renderer.labels.template.horizontalCenter = "right";
				categoryAxis.renderer.labels.template.verticalCenter = "middle";
				categoryAxis.tooltip.label.rotation = 270;
				categoryAxis.tooltip.label.horizontalCenter = "right";
				categoryAxis.tooltip.label.verticalCenter = "middle";

				let valueAxis = chart.yAxes.push(new am4charts.ValueAxis());
				valueAxis.title.text = "Quantidade de treinamento a vencer";
				valueAxis.title.fontWeight = "bold";

				// Create series
				var series = chart.series.push(new am4charts.ColumnSeries3D());
				series.dataFields.valueY = "qtdTreinamento";
				series.dataFields.categoryX = "empresa";
				series.name = "qtdTreinamento";
				series.tooltipText = "{categoryX}: [bold]{valueY}[/]";
				series.columns.template.fillOpacity = .8;

				var columnTemplate = series.columns.template;
				columnTemplate.strokeWidth = 2;
				columnTemplate.strokeOpacity = 1;
				columnTemplate.stroke = am4core.color("#FFFFFF");

				columnTemplate.adapter.add("fill", (fill, target) => {
					return chart.colors.getIndex(target.dataItem.index);
				})

				columnTemplate.adapter.add("stroke", (stroke, target) => {
					return chart.colors.getIndex(target.dataItem.index);
				})

				chart.cursor = new am4charts.XYCursor();
				chart.cursor.lineX.strokeOpacity = 0;
				chart.cursor.lineY.strokeOpacity = 0;

			}); am4core.ready();



		},function (error) {
			console.log(error);
			getShowToast('Erro','Não foram encontrado treinamentos','error');

		});

		$scope.deslogar = function(){
			localStorage.clear();
			window.location="login.html";
		}


		$http({method:'GET',url: 'http://localhost:8082/workSecurity/planotrabalhos/'+$scope.cpfUser}).then(function(response){	
			am4core.ready(function() {
				am4core.useTheme(am4themes_animated);

					var chart = am4core.create("chartdiv1", am4charts.PieChart3D);
					chart.hiddenState.properties.opacity = 0; // this creates initial fade-in

					chart.data = response.data;

					chart.innerRadius = am4core.percent(40);
					chart.depth = 50;

					chart.legend = new am4charts.Legend();
					chart.legend.position = "center";

					var series = chart.series.push(new am4charts.PieSeries3D());
					series.dataFields.value = "qtdTreinamento";
					series.dataFields.depthValue = "empresa";
					series.dataFields.category = "empresa";
					series.slices.template.cornerRadius = 5;
					series.colors.step = 3;


			});am4core.ready();

},function (error) {
	console.log(error);
	getShowToast('Erro','Não foram encontrado planos de trabalho','error');

});


		};

		function getShowToast(heading,text,icon){
			$.toast({
				heading: heading,
				text: text,
				icon: icon,
				position: 'top-center'
			});
		}


	}]);	