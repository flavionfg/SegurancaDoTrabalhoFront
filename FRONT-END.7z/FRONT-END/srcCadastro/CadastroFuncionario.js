	var app = angular.module('myApp', ['ngMask','ngFileUpload',"ngSanitize", "ngCsv"]);

	function redirectTo(ref) {
		window.location.href = ref;
	}
	

	app.controller('myController',['$scope', '$http', function($scope, $http,$window){

		$scope.onExit = function(){
			redirectTo("index.html");
		}

		$scope.cpfUser = '';
		$scope.funcionarios = [];
		$scope.funcionario = {};
	
		$scope.init = function () {

			$scope.cpfUser = localStorage.getItem('cpfUser');

			if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");
	
			$http({method:'GET',url: 'http://localhost:8082/workSecurity/empresauser/'+$scope.cpfUser}).then(function(response){		
				if(response.status === 200 || response.status === 201 ){
					if(response.data === null || response.data === undefined ){
						getShowToast('Erro','As empresas não foram encontradas','error');
						return;
					}
					$scope.empresas = response.data;
	
	
				}
				else{
					getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
					return;
				}
			});
		}; 
	
		$scope.deslogar = function(){
			localStorage.clear();
			window.location="login.html";
		}
	
		//função salva o funcionario faz a listagem do funcionario no datatable
		$scope.salvarFuncionario = function(funcionario){
			var funcionarios = [];
			if(funcionario.length > 0){
				funcionarios = funcionario;
			}else{
				funcionarios.push(funcionario);
			}
			
			var empresa = {};
			for(var i = 0; i < funcionarios.length; i++){
				
				var funcionario = {};
				funcionario = funcionarios[i];
				funcionario.nome = funcionarios[i].primeiroNome+ " " + funcionarios[i].segundoNome;
				funcionario.idEmpresa = $scope.empresaSelecionada;
				console.log($scope.empresaSelecionada);
				$scope.funcionarios.push(funcionario);
			}
			console.log($scope.empresaSelecionada);
			$scope.body = angular.toJson($scope.funcionarios);
	
			$scope.funcionarios = [];
			delete $scope.funcionario;
			$scope.funcionarioForm.$invalid = true;
	
			
	
			$http.post('http://localhost:8082/workSecurity/funcionario', $scope.body).then(function(response){	
				$scope.funcionarioForm.$setUntouched(true);
				if(response.status === 200 || response.status === 201 ){
	
					
					$scope.getFuncionariosSetorVo($scope.empresaSelecionada);
					$scope.funcionarios = [];
					getShowToast('Sucesso','Salvo com sucesso','success');
					
				}else{
	
					getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
	
				}
	
				
			},function(error){
				console.log(error);
				$scope.funcionarioForm.$setUntouched(true);
				getShowToast('Erro',error.data.message === 'CPF invalido' ? 'CPF invalido' : 'Erro ao salvar. Favor verificar os valores informados' ,'error');
	
			});
	
		}
	
		//função pega valor do fileupload
		$scope.SelectFile = function (file) {
			$scope.SelectedFile = file;
		};
	
		// função converte o arquivo csv
		$scope.Upload = function () {
			var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.csv)$/;
			if (regex.test($scope.SelectedFile.name.toLowerCase())) {
				if (typeof (FileReader) != "undefined") {
					var reader = new FileReader();
					reader.onload = function (e) {
						var customers = new Array();
						var linhas = [];
						linhas = e.target.result.split("\r\n");
						console.log(linhas);
						var funcionarios = converterJson(linhas);
	
						
						$scope.salvarFuncionario(funcionarios);
						
						
					}
					reader.readAsText($scope.SelectedFile);
				} else {
					$window.alert("This browser does not support HTML5.");
				}
			} else {
				getShowToast('Erro','O arquivo deve ser do tipo csv','error');
			}
		}
	
		//função auxiliar para conversão do csv
		function converterJson(linhas){
			
			if(linhas === null ) return;
			console.log(linhas[0]);
			var headers= linhas[0].split(",");
			var result = [];
			for(var i=1;i<linhas.length;i++){
	
				var obj = {};
				var currentline=linhas[i].split(",");
	
				for(var j=0;j<headers.length;j++){
					obj[headers[j]] = currentline[j];
				}
				if(obj.cpf !== undefined)
				result.push(obj);
	
			}
			console.log(result);
			
			return result;
		}
	
		// função que transforma objeto empresa em json
		$scope.setorJson = function(){
	
			$scope.setorBody = angular.toJson($scope.funcionarios);
	
		};
	
		//função para editar o funcionário
		$scope.editarfuncionario = function(funcionario){
			$scope.funcionario = angular.copy(funcionario);
		}
	
		//função carrega ver funcionario
		$scope.getFuncionario = function(funcionario){
			$scope.verFuncionario = funcionario;
		}
	
		$scope.setEmpresaSelecionada = function(empresa){
			getSetores(empresa);
			$scope.empresaSelecionada = empresa;	
		}
	
		//função para carregar o data table
		$scope.getFuncionariosSetorVo = function(empresa){
	
			if(empresa === null || empresa === undefined){
				getShowToast('Erro','Uma empresa deve ser selecionada!','error');
			}
			
			$http({method:'GET',url: 'http://localhost:8082/workSecurity/funcionarioempresa/'+empresa.id}).then(function(response){
				if(response.status === 200 || response.status === 201 ){
					if(response.data === null || response.data === undefined ){
						getShowToast('Erro','Erro ao listar os funcionários','error');
						return;
					}else{					
						getJqueryDatatable();
						$scope.funcionariosTable = response.data;
					}
				}
			});
	
		}
	
		function getSetores(empresa){
	
			$http({method:'GET',url: 'http://localhost:8082/workSecurity/allsetor/'+empresa.id}).then(function(response){
				if(response.status === 200 || response.status === 201 ){
					if(response.data === null || response.data === undefined ){
						getShowToast('Erro','Erro ao listar os funcionários','error');
						return;
					}else{		
						$scope.setores = [];		
						for(var i = 0 ; i < response.data.length ; i++){
						$scope.setores.push(response.data[i].nome);
						}
					}
				}
			});
			
		}
	
		function getShowToast(heading,text,icon){
			$.toast({
				heading: heading,
				text: text,
				icon: icon,
				position: 'top-center'
			});
		}
		
		$scope.sexos = [
			"Masculino",
			"Feminino"
		];
	
		$scope.periodos = [
			"Manhã",
			"Tarde",
			"Noite",
			"Madrugada"
		];
	
	
		function getJqueryDatatable(){
			$('#table').DataTable().clear().destroy();
			$(document).ready(function() {
				
				$('#table').DataTable( {
					"language":{
						"sEmptyTable": "Nenhum registro encontrado",
						"sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
						"sInfoEmpty": "Mostrando 0 até 0 de 0 registros",
						"sInfoFiltered": "(Filtrados de _MAX_ registros)",
						"sInfoPostFix": "",
						"sInfoThousands": ".",
						"sLengthMenu": "_MENU_ resultados por página",
						"sLoadingRecords": "Carregando...",
						"sProcessing": "Processando...",
						"sZeroRecords": "Nenhum registro encontrado",
						"sSearch": "Pesquisar",
						"oPaginate": {
							"sNext": "Próximo",
							"sPrevious": "Anterior",
							"sFirst": "Primeiro",
							"sLast": "Último"
						},
						"oAria": {
							"sSortAscending": ": Ordenar colunas de forma ascendente",
							"sSortDescending": ": Ordenar colunas de forma descendente"
						},
						"showButtonPanel":  false
					},
					"order": [[ 5, "desc" ]]
				} );          
			} );     
		}
	
	}]);
	
	