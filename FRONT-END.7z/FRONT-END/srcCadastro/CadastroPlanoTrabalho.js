var app = angular.module('myApp', ['ngMask']);

function redirectTo(ref) {
	window.location.href = ref;
}

app.controller('myController',['$http','$scope' , function( $http,$scope){

	$scope.onExit = function(){
		redirectTo("index.html");
	}


	$("#date").keypress(function (e) {
      return false;
	}); 

	$("input[name='dataFim']").keypress(function (e) {
      return false;
	}); 

	$scope.cpfUser = '';
	$scope.empresas;
	$scope.funcionarios = [];
	$scope.setores = [];
	$scope.todate;
	$scope.dataMinima;
	function dataHoje() {
            var data = new Date();
            var dia = data.getDate();
            dia = dia < 10  ? "0"+dia : dia;
            var mes = data.getMonth() + 1;
            mes = mes < 10  ? '0'+mes : mes;
            var ano = data.getFullYear();            
            return [ano, mes,dia ].join('-');
    }



    $scope.minDate = function(data){

    		if(data <$scope.todate){
    			$scope.plano.dataInicio = $scope.todate;
    		}

    		var dia = data.getDate();
            dia = dia < 10  ? "0"+dia : dia;
            var mes = data.getMonth() + 1;
            mes = mes < 10  ? '0'+mes : mes;
            var ano = data.getFullYear();            
			$scope.dataMinima = [ano, mes,dia ].join('-');    	
    }

	$scope.init = function () {

		$scope.cpfUser = localStorage.getItem('cpfUser');

		if($scope.cpfUser === null || $scope.cpfUser === undefined)redirectTo("login.html");


		$scope.todate = dataHoje();
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/empresauser/'+$scope.cpfUser}).then(function(response){
			$scope.empresas = response.data;

			if($scope.funcionarios === null || $scope.funcionarios === undefined){
				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
			}
		});
	};


	$scope.getGrupo = function(grupoRisco) {

		if(grupoRisco.numero === "1")	
			$scope.plano.risco = "Físico"	;			

		if(grupoRisco.numero  === "2")
			$scope.plano.risco = "Químico";

		if(grupoRisco.numero  === "3")	
			$scope.plano.risco = "Biológico";	

		if(grupoRisco.numero  === "4")	
			$scope.plano.risco = "Ergonômico";

		if(grupoRisco.numero  === "5")	
			$scope.plano.risco = "Mecânico";

	}


	$scope.deslogar = function(){
		localStorage.clear();
		window.location="login.html";
	}
	
	$scope.savePlanoTrabalho = function(plano){
		
		$scope.plano = plano;
		$scope.plano.responsavel = plano.idFuncionario.nome;
		$scope.plano.empresa = plano.idEmpresa.nomeFantasia;
		$scope.plano.grupoRisco = plano.grupoRisco.numero;
		$scope.body = angular.toJson($scope.plano);


		$http.post('http://localhost:8082/workSecurity/planotrabalho', $scope.body).then(function(response){	
		
			if(response.status === 200 || response.status === 201 ){
				
				getShowToast('Sucesso','Salvo com sucesso, favor consultar a aba HISTORICO!','success');
				
			}else{

				getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');

			}

		});
	
	}

	$scope.getFuncionarioSetor = function(empresa){

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/funcionarioempresa/'+empresa.id}).then(function(response){
			

			if(response.status === 200 || response.status === 201){
				$scope.funcionarios = response.data;
				if($scope.funcionarios === null || $scope.funcionarios === undefined){
					$.toast({
						heading: 'Error',
						text: 'Os funcionarios não foram encontrados, favor cadastrar ',
						icon: 'error',
						position: 'top-center'
					});
				}
			}

			getSetores(empresa);

		});

	}

	function getSetores(empresa){

		$http({method:'GET',url: 'http://localhost:8082/workSecurity/allsetor/'+empresa.id}).then(function(response){
			if(response.status === 200 || response.status === 201 ){
				if(response.data === null || response.data === undefined ){
					getShowToast('Erro','Erro ao realizar a operação, favor tentar novamente!','error');
					return;
				}else{		
					$scope.setores = [];		
					for(var i = 0 ; i < response.data.length ; i++){
					$scope.setores.push(response.data[i].nome);
					}
				}
			}
		});
		
	}

	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			position: 'top-center'
		});
	}

	$scope.plano = {};

	$scope.grupo = {};

	$scope.gruposRisco = [  
	{  
		"numero":"1"	

	},
	{  
		"numero":"2"

	},
	{  
		"numero":"3"

	},
	{  
		"numero":"4"

	},
	{  
		"numero":"5"

	}
	];

	





}]);

