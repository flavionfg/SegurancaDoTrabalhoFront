var app = angular.module('myApp', ['ngMask']);

function redirectTo(ref) {
	window.location.href = ref;
}

app.controller('myController',['$scope', '$http', function($scope, $http){

	$scope.onExit = function(){
		redirectTo("login.html");
	}

	$scope.salvarUsuario = function(usuario){
		$scope.usuario = usuario;
		$scope.usuario.nome = `${$scope.usuario.primeiroNome} ${$scope.usuario.segundoNome}`
		$scope.body = angular.toJson($scope.usuario);
		$http.post('http://localhost:8082/workSecurity/usuario', $scope.body).then(function(response){
			if(response.status === 200 || response.status === 201 ){
				$scope.usuario = [];
				delete $scope.usuarioForm;
				getShowToast('Sucesso','Salvo com sucesso','success');
				redirectTo("login.html");
			}
		}).catch(error => {
			if(error.status === 500){
			getShowToast('Erro','Este CPF já esta cadastrado em nosso sistema, favor inserir um novo registro!','error');
			}else{
				getShowToast('Erro','Erro ao realizar a operação, favor inserir um CPF válido!','error');
			}
		});
				
	}

	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			position: 'top-center'
		});
	};



}]);