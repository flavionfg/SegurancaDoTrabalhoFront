var app = angular.module('myApp', []);

function redirectTo(ref) {
	window.location.href = ref;
}

app.controller('myController',['$scope', '$http', function($scope, $http){


	$scope.logar = function(usuario){
		
		$http({method:'GET',url: 'http://localhost:8082/workSecurity/usuario/valida/?nomeUsuario='+usuario.nomeUsuario+'&senha='+usuario.senha}).then(function(response){	
			
			if(response.status === 200 || response.status === 201 ){
				localStorage.setItem('cpfUser', response.data.cpf);
				redirectTo("index.html");
			}else{
				getShowToast('Erro','Erro ao logar','error');
			}

		},function(error){
			localStorage.clear();
			getShowToast('Erro','Cadastro não encontrado, por favor tentar novamente ou cadastre-se!','error');
		});

	};

	function getShowToast(heading,text,icon){
		$.toast({
			heading: heading,
			text: text,
			icon: icon,
			showHideTransition: 'slide',
			position: 'top-center'
		});
	};

}]);